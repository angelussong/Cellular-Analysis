clear
clc
tmp=importdata('curr_population_LHS');
lee=length(tmp);
fput = fopen( 'HETD2_Apr20IR3a.txt', 'wt' );
% WTD1 Nov3IR3a: 0.642890	3.187300	0.000234	13.585286	1.208750	4.527500	4.886875
% WTD1_Nov3IR3a: 1.37	2.6	0.000222	13.67	1.58	4.63	5.42 2.10Hz
% WTD2_Nov9IR3b: 1.6    2.7 0.000222    13.94   1.63    4.84    5.67    2Hz
% HETD1_Nov4IR3e: 1.7   2.7 0.000165    11.49   1.62    4.99    5.82 2.73Hz
% HETD2_May4IR2a: 1.9   2.5 0.000220    13.43   1.86    5.15    6.13 2.13Hz
% WTD2 INTERVAL=23500, NSPIKES=20, 84 EPSC 50 sec = 1.68 Hz, perfect!!!!
% HETD1 INTERVAL=25500, NSPIKES=20, 79 EPSC 50 sec = 1.58 Hz, close to 1.54
% HETD2 INTERVAL=32000, NSPIKES=20, 61 EPSC 50 sec = 1.22 Hz, close to 1.22
for tcount=1:lee
    
T_sim=3500;
trise=tmp(tcount,2);
tdecay=tmp(tcount,3);
gampa=tmp(tcount,1);
Interval = 12000;
Nspikes = 40;
fint = fopen('main_PFC-ApBas_fig11epsc.hoc','r');
fout = fopen('main_PFC-ApBas_fig11epsc_out.hoc','w');
linenum = 0; 
fprintf(fput,'%f\t%f\t%f\t',trise,tdecay,gampa);
while ~feof(fint)
     tline = fgetl(fint);
     linenum = linenum+1;
     if linenum>=0
        if linenum==198
            fprintf(fout,'   xopen("PFC-V1_AddSynapses_neg.hoc")\n')
        elseif linenum==213
            fprintf(fout,'   endSyn = %d\n',T_sim);
        elseif linenum==220
            fprintf(fout,'   synTweak(nSynapse,%.4f,%.4f,%.7f,"fig11_PFCapic")\n',trise,tdecay,gampa);       
        else
         fprintf(fout,'%s\n',tline);

        end
     end

end
fclose(fint);
fclose(fout);


fint = fopen('PFC-V1_AddSynapses_negexp.hoc','r');
fout = fopen('PFC-V1_AddSynapses_neg.hoc','w');
linenum = 0; 
while ~feof(fint)
     tline = fgetl(fint);
     linenum = linenum+1;
     if linenum>=0 
        if linenum==22
            fprintf(fout,'INTERVAL = %d\n',Interval);
        elseif linenum==23
            fprintf(fout,'NSPIKES = %d\n',Nspikes);       
        elseif linenum==65
            fprintf(fout,'AMPA_tau1 = %.4f //(ms)\n',trise);
        elseif linenum==66
            fprintf(fout,'AMPA_tau2 = %.4f //(ms),\n',tdecay);       
        elseif linenum==69
            fprintf(fout,'AMPA_g = %.7f // change in conductance,\n',gampa);
        else
            fprintf(fout,'%s\n',tline);
        end
     end
end
fclose(fint);
fclose(fout);
 


fprintf('Testing parameters ');

fprintf('\n');

syscmd = '/Applications/NEURON-7.5/nrn/x86_64/bin/nrniv -nogui main_PFC-ApBas_fig11epsc_out.hoc';


system(syscmd);


[avamp,tr,td,avhfw]=read_EPSCsims_mdb(trise,tdecay,gampa);
fprintf(fput,'%f\t%f\t%f\t%f\n',avamp,tr,td,avhfw);
delete *.Ibin
delete *_dist.txt
end
fclose(fput);

