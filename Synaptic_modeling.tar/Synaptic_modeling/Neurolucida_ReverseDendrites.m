function [] = Neurolucida_ReverseDendrites(in_base, lines_to_reverse)
%
%   When importing ASC files from Neurolucida into NEURON version 7.4,
%   sometimes the dendrites have been written to the file in the reverse
%   order (e.g. from tip to branch point instead of vice versa).  This file
%   echos everything from the input file, except it reverses the order of
%   every dendrite that starts at the specified line numbers.  These line
%   numbers come from NEURON's Import3D function, after an initial attempt
%   to import the file leads to connection problems.
%
%   input   in_base             name of input file, except for ASC extension.
%           lines_to_reverse    vector of starting points for all dendrites
%                               that need to be reversed.
%   output  an ASC file, named "in_name"_reversedSomeDend.ASC
%
%   Christina Weaver, March 2017
%

in_name = sprintf('%s.ASC',in_base);
out_name = sprintf('%s_reversedSomeDend.ASC',in_base);

if( ~exist(in_name,'file') )
    fprintf('File %s not found.\n',in_name);
    return;
else
    fprintf('\n\nWorking on file %s\n',in_base);
end;

% sort the lines_to_reverse list
lines_to_reverse = sort(lines_to_reverse);
lines_to_reverse = lines_to_reverse-1;

fin  = fopen(in_name,'r');
fout = fopen(out_name,'w');

lineID = 0;
tline = fgets(fin);
% tline = fgetl(fin);
revID = 1;
while ischar(tline)
    lineID = lineID +1;
    % Missing case:  what if we are past all the dendrites we have to
    % reverse?  Then echo everything left.
    
    if( lineID > lines_to_reverse(end) )
        fprintf(fout,tline);
        %        fprintf(fout,'\n');
    elseif( lineID < lines_to_reverse(revID) )
        % echo this line to output file.
        hasBSlash = strfind(tline,'\');
        if( ~isempty(hasBSlash) )
            % filenames.  Have to parse this separately.
%             fprintf('Found filename.\n');
            st_loc = 1;
            for i=1:length(hasBSlash)
                fprintf(fout,'%s',tline(st_loc:hasBSlash(i)-1));
                fprintf(fout,'\\');
                st_loc = hasBSlash(i)+1;
            end;
            fprintf(fout,'%s',tline(st_loc:end));
        else
            fprintf(fout,tline);
        end;
        %        fprintf(fout,'\n');
    else
        % we need to read in the whole dendrite, reverse it, and echo it to
        % the output file.  Then continue reading.
        
        fprintf('Now on line %d\n',lineID);
        [revOK, morphdat, lineID, tline] = try_reverse(fin,fout,tline,lines_to_reverse(revID),lineID);
        print_dendrite(morphdat,fout);
        fprintf(fout,tline);
        %        fprintf(fout,'\n');
        
        % now when we're done, increment revID
        revID = revID + 1;
    end;
    tline = fgets(fin);
    
end


fclose(fin);
fclose(fout);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%  read ahead to save the entire dendrite branch in morphdat.  If ending is
%  'Normal' or 'Generated', reverse the order of the dendrite and return
%  revOK = 1; else copy data as is into morphdat and revOK = 0;
function [revOK, morphdat, lineID, new_tline] = try_reverse(fin,fout,tline,revLine,prev_lineID)

morphdat = [];

lineID = prev_lineID;
% first - read the current line and parse into morphdat
[pointvec, cnt] = sscanf(tline,'%*s %f   %f   %f     %f %*s',[1 4]);
while( cnt > 0 & ischar(tline))
    morphdat(end+1,:) = pointvec;
    
    %         tline = fgetl(fin);
    tline = fgets(fin);
    if( ischar(tline) )
        [pointvec, cnt] = sscanf(tline,'%*s %f   %f   %f     %f %*s',[1 4]);
        lineID = lineID +1;
    end;
end;

% now either at the end of the dendrite, or end of file.
is_nml = strfind(tline,'Normal');
is_gen = strfind(tline,'Generated');
if( ~isempty(is_nml) | ~isempty(is_gen) )
    revOK = 1;
    
    % assume it's OK to reverse the order of morphdat.
    tmp_morph = flipud(morphdat);
    morphdat = tmp_morph;
    fprintf('\tIt is OK to reverse the dendrite starting at %d.\n',revLine);
else
    revOK = 0;
    % leave morphdat unchanged.
    fprintf('\tProblem with reversing dendrite starting at %d.\n',revLine);
end;

new_tline = tline;

return;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% print this data to the output file, according to the Nuerolucida ASC
% formatting.
function  [] = print_dendrite(morphdat,fout)

for i = 1 : size(morphdat,1)
    fprintf(fout,'  (  %.2f   %.2f   %.2f     %.2f)  ; ',morphdat(i,1),morphdat(i,2),morphdat(i,3),morphdat(i,4));
    switch i
        case 1
            fprintf(fout,'Root\n');
        case 2
            fprintf(fout,'1, R\n');
        otherwise
            fprintf(fout,'%d\n',i-1);
    end;
    
end;

return;

