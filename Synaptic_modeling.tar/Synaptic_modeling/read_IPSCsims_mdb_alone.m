
clear
clc

fbase = 'fig12_PFCapic';
%WTD1_Nov9IR2a

gGABA = 0.0027;
tau1 = 3.0053;
tau2 = 6.57;

writeSmry = 0;

inbase = sprintf('%s_INtR%.4f_tF%.2f_gGAB%.5f',fbase,tau1,tau2,gGABA);

figttl = sprintf('PFC test: t_1 %.2f t_2 %.4f gGAB %.5f',tau1,tau2,gGABA);
makeDistPlot = 1;
TipsOnly = 1;

[t,v]=readNRNbin_Vclamp(inbase,0);

ylim([-0.05 0])
txt_fname = sprintf('%s_dist.txt',inbase);
[dat] = dlmread(txt_fname);
nSyn = size(dat,1);

tmp_ras=importdata('test_raster.txt');

sTimes = tmp_ras(:,1);
spk_ind=tmp_ras(:,2);
l_spks=length(sTimes);

idx=zeros(l_spks-1,2);
PSCbase=zeros(l_spks-1,1);

v_IPSP = zeros(60000,l_spks-1);
peak = [];
amp = [];
rise = [];
decay = [];
hfw = [];
% figure(1)
emp_spks=[1 l_spks];
emp_spks2=[];
for k=2:l_spks-2
idx(k,:) = [min(find(t >= sTimes(k)))  max(find(t < sTimes(k+1)))];
% idx(k,2)-idx(k,1);
% figure(1)
% plot(v(idx(k,1):idx(k,2)))

tstep = [0 : idx(k,2)-idx(k,1)-1];
t_IPSP = t(1+tstep);


    idx_IPSP = idx(k,1);
    tmp = v(idx(k,1)+1:idx(k,2));
    [mn,mnI]=max(tmp);
    
    v_IPSP(1+tstep,k-1) = tmp-tmp(1);

    peak(end+1,:) = [t_IPSP(mnI)  abs(mn-tmp(1))];
    
    [amp_tmp,rise_tmp,decay_tmp,hfw_tmp]=analyze_IPSC(t_IPSP,tmp); 
    if (decay_tmp~=0)
        amp(end+1)=amp_tmp;
        rise(end+1)=rise_tmp;
        decay(end+1)=decay_tmp;
        hfw(end+1)=hfw_tmp;
    else
        emp_spks=[emp_spks k];
        emp_spks2=[emp_spks2 k];
    end
    
end

v_IPSP(30000:end,:)=[];

% nSyn = size(v_EPSP,1);
fprintf('Found %d IPSCs\n',length(amp)-length(find(amp==0)));
fprintf('Mean amp\t%.2f\n',mean(nonzeros(amp)*1e3));
fprintf('Mean rise\t%.2f\n',mean(nonzeros(rise)));
fprintf('Mean decay\t%.2f\n',mean(nonzeros(decay)));
fprintf('Mean 1/2 width\t%.2f\n',mean(nonzeros(hfw)));
mean_IPSP=zeros(length(v_IPSP),1);
for i=1:length(v_IPSP)
mean_IPSP(i) = mean(v_IPSP(i,1:l_spks-2));
end

figure(1)
l_IPSP=length(v_IPSP);
t_plot=0:0.025:0.025*(l_IPSP-1);
for i=1:size(v_IPSP,2)
        plot(t_plot,v_IPSP(:,i)*1000,'k',t_plot,mean_IPSP*1000,'r');
        hold on;
end
plot(t_plot,mean_IPSP*1000,'r');
ttl = sprintf('%s:  superimposing all IPSCs',figttl);
title('superimposed IPSCs');
xlabel('time (ms)');

ylabel('IPSC (pA)');
fname = sprintf('%s_meanIPSCond.fig',inbase);


