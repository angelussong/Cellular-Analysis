function plot_morphDiam(fbase);

% now read the diameter file and plot results.
frq = [500];
lam = [0.1];
col = 'rgbcmyk';
ncol = length(col);
for iF = 1 : length(frq)
    for iL = 1 : length(lam)
        
        diamName = sprintf('%s_diamForMatlab_Hz%dLambda%.2f.txt',fbase,frq(iF),lam(iL));
        
        if( ~exist(diamName,'file')) continue; end;
        ddata = dlmread(diamName);
        nDend = max(ddata(:,1))+1;
        
        figure;
        for i = -1 : nDend-1
            if( i == -1 ) cidx = 7;
            else
                cidx = mod(i,ncol)+1;
            end;
            didx = find(ddata(:,1)==i);
            % now plot this on the graph.
            coltag = sprintf('%co-',col(cidx));
            if( ~isempty(didx) )
                plot(ddata(didx,3),ddata(didx,4),coltag);
            else
                printf('Dendrite %d, found %d points\n',i,length(didx));
            end;
            hold on;
            
        end;
        ttl = sprintf('%s diameters:  %d Hz, %.2f lambda',fbase,frq(iF),lam(iL));
        title(ttl);
        % figname = sprintf('%s_diam.fig',fbase);
        figname = sprintf('%s_diam_Hz%dLambda%.2f.fig',fbase,frq(iF),lam(iL));
        saveas(gcf,figname);
    end;
end;




