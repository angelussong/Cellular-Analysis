function [] = write_nrn_file_Sep2017(params,hocbase,outname,rewrite)

if( ~exist('rewrite','var') ) rewrite = 1; end;

fname = sprintf('%s.hoc',hocbase);
fout = fopen(fname,'w');

% here, create a temporary .hoc file to use just once.  The idea is that
% the new .hoc opens up an existing "main" .hoc file which loads the
% Multiple Run Fitter.  Then set the NEURON code to run the
% parameter values sent from this function, using the set_params() command.
%  Finally, make sure you run the Multiple Run Fitter and record its total
%  error value to a txt file.  The text file will then be read by the
%  Matlab optimization code.  The value listed in that file will be used as
%  the value of the error function that the Matlab optimization code is
%  trying to minimize.

% A bit confusing - so please let me know if you have questions!
%
% Christina Weaver, 9/18/17 - based on code I wrote from 2008-2010

fprintf(fout,'xopen("nrnmain_fitAct_MorphC.hoc")\n\n');
n_par = size(params,2);
for i = 1 : size(params,1)
    fprintf(fout,'set_%dparams(',n_par);
    for j=1:n_par
        fprintf(fout,'%g',params(i,j));
        if( j < n_par ) fprintf(fout,','); end;
    end;
    if( rewrite )
        fprintf(fout,')\ncalc_error_overwrite("%s",%d)\n',outname,n_par);
    else
        fprintf(fout,')\ncalc_error("%s",%d)\n',outname,n_par);
    end;
end;
fprintf(fout,'\nquit()\n');

fclose(fout);

return;