clear
clc

 fid = fopen('myfile.txt')
 linenum = 0; 
 while ~eof(fid)
      tline = fgetl(fid);
      linenum = linenum+1;
      if linenum>=131 
         if linenum==131
            fprintf(fid,'a = %f',%whatever you want it to swap to)
         elseif linenum==132
            fprintf(fid,'b = %f',%whatever you want it to swap to)       
         else
            fprintf(fid,tline)
         end
 end
fprintf('Testing parameters ');
fprintf('%g\t',exp(par));
fprintf('\n');
fbase = 'HanbingTest';
txtname = sprintf('%s.txt',fbase);

syscmd = sprintf('/Applications/NEURON-7.4/nrn/x86_64/bin/nrniv -nogui %s.hoc',fbase);
write_nrn_file_Sep2017(exp(par),fbase,txtname,0);

system(syscmd);

mtx = load(txtname);

err = mtx(end,end);

return;