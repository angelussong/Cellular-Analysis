clear
clc
% tmp=importdata('EPSC_WTD1_sameden.txt');
% dist_WTD1=tmp(:,1);
% normamp_WTD1=tmp(:,2);
% amp_WTD1=tmp(:,3);
% createFit_WTD1(dist_WTD1,amp_WTD1);
% figure(2)
% plot(dist_WTD1,amp_WTD1,'o','MarkerSize',10,'Color', [0.5 0.51 0.52]);
% ylim([0 0.018])
% xlim([0 350])
% 
% figure(2)
% 
% tmp1=importdata('EPSC_HETD1_sameden.txt');
% dist_HETD1=tmp1(:,1);
% normamp_HETD1=tmp1(:,2);
% amp_HETD1=tmp1(:,3);
% plot(dist_HETD1,amp_HETD1,'o','MarkerSize',10,'Color',[0.22 0.71 0.29],'MarkerFaceColor',[0.22 0.71 0.29]);
% ylim([0 0.018])
% xlim([0 350])
% figure(2)
% createFit_HETD1(dist_HETD1, amp_HETD1)
% ylim([0 0.018])
% xlim([0 350])


tmp=importdata('WTD1_delay.txt');
dist_WTD1=tmp(:,1);
delay_WTD1=tmp(:,2);
plot(dist_WTD1,delay_WTD1,'b.');
hold on;
%Linear model Poly1:
%      f(x) = p1*x + p2
% Coefficients (with 95% confidence bounds):
%        p1 =    0.006225  (0.006067, 0.006383)
%        p2 =       1.971  (1.961, 1.981)
% 
% Goodness of fit:
%   SSE: 126.4
%   R-square: 0.6257
%   Adjusted R-square: 0.6256
%   RMSE: 0.1882

tmp2=importdata('HETD1_delay.txt');
dist_HETD1=tmp2(:,1);
delay_HETD1=tmp2(:,2);
plot(dist_HETD1,delay_HETD1,'r.');
% Linear model Poly1:
%      f(x) = p1*x + p2
% Coefficients (with 95% confidence bounds):
%        p1 =    0.007858  (0.007705, 0.008012)
%        p2 =       1.909  (1.898, 1.92)
% 
% Goodness of fit:
%   SSE: 434.1
%   R-square: 0.6109
%   Adjusted R-square: 0.6109
%   RMSE: 0.2602

