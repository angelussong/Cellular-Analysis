clear
clc

tmp=importdata('results.txt');
t_rise=tmp(:,1);
t_decay=tmp(:,2);
g_ampa=tmp(:,3);

amp=tmp(:,4);
tau_rise=tmp(:,5);
tau_decay=tmp(:,6);
hwf=tmp(:,7);

x1=t_rise;
x2=t_decay;
x3=g_ampa;

% y=hwf; % here is the result we want for regression
% 
% % this is for tau_rise and tau_decay
%  X=[ones(length(x1)) x1 x2 x1.*x2];
% % X=[ones(length(x1)) x1 x2 exp(x1) exp(x2) log(x1) log(x2)];
% % this is for hwf
% % X=[ones(length(x1)) x1 x2 x1.*x2 x1.*x1 x2.*x2];
% [b,bint]=regress(y,X);
% 
% scatter3(x1,x2,y,'filled','red')
% hold on
% x1fit = min(x1):0.005:max(x1);
% x2fit = min(x2):0.005:max(x2);
% [X1FIT,X2FIT] = meshgrid(x1fit,x2fit);
% YFIT = b(1) + b(2)*X1FIT + b(3)*X2FIT + b(4)*X1FIT.*X2FIT;
% % YFIT = b(1) + b(2)*X1FIT + b(3)*X2FIT + b(4)*X1FIT.*X2FIT + b(5)*X1FIT.*X1FIT + b(6)*X2FIT.*X2FIT + b(7)*exp(X1FIT) + b(8)*exp(X2FIT) + b(9)*log(X1FIT) + b(10)*log(X2FIT);
% % YFIT = b(1) + b(2)*X1FIT + b(3)*X2FIT + b(4)*exp(X1FIT) + b(5)*exp(X2FIT) + b(6)*log(X1FIT) + b(7)*log(X2FIT);
% 
% mesh(X1FIT,X2FIT,YFIT)
% xlabel('t rise')
% ylabel('t decay')
% zlabel('tau rise')
% view(50,10)
% zlim([0 6]);

y=amp;
XX=[ones(length(x3),1) x3];
b=XX\y;
Ycal=XX*b;
plot(x3,Ycal,'--');
hold on;
plot(x3,y,'r.')
% Here is the result: amp= 0.0989+57659*g_ampa=13.69627273
