
clear
clc
% str = {'Apr25IR2a' 'Nov7IR3a' 'May4IR2f' 'May4IR2e' 'Apr25IR2c' 'Apr15IR2c' 'Apr13IR3b' 'Apr13IR2c' 'Apr27IR3h' 'Nov4IR3e' 'Nov4IR3f' 'Nov4IR2g' 'May6IR2f' 'Nov10IR3e'};
% str = {'Nov8IR3a','Nov9IR2a','Nov3IR3a','Nov9IR3c','Nov3IR2c','May9IR3b','May9IR2a','Apr29IR2b','Apr29IR2a','Apr12IR2a'};
str = {'Apr25IR2a'};
celltype = 'HETD1';
xx0=zeros(30000,1);
yy0=zeros(30000,1);
yy_v0=zeros(30000,1);
indx=1;
indy=1;
% cd WTD1_dendrogram
llx=zeros(length(str),1);
lly=zeros(length(str),1);
for CEL = 1:length(str)

    cd([str{CEL},'_',celltype])
fbase = 'fig11_PFCapic';
% gAMPA = 0.000268;
% tau1 = 2.0053;
% tau2 = 1.5669;
% gAMPA = 0.00021;
% tau1 = 2.7006;
% tau2 = 2.1829;
% gAMPA = 0.0001630;
% tau1 = 2.1739;
% tau2 = 1.6433;

%representative WTD1
%gAMPA = 0.000214;
%tau1 = 2.2933;
%tau2 = 1.7977;

% gAMPA = 0.000203;
% tau1 = 4.532;
% tau2 = 1.7101;
% gAMPA = 0.000218;
% tau1 = 6.9143;
% tau2 = 2.9064;
% gAMPA = 0.000104;
% tau1 = 3.5983;
% tau2 = 2.4589;


%representative HETD1
gAMPA = 0.0002320;
tau1 = 5.0149;
tau2 = 2.6918;

clear t v dat txt_fname tmp_ras targ_spks xx yy
writeSmry = 0;

inbase = sprintf('%s_tR%.4f_tF%.4f_gAMP%.7f',fbase,tau1,tau2,gAMPA);

figttl = sprintf('PFC test: t_1 %.4f t_2 %.4f gAMP %.7f',tau1,tau2,gAMPA);
makeDistPlot = 1;
TipsOnly = 1;

[t,v]=readNRNbin_Vclamp(inbase,0);


ylim([-0.05 0])
txt_fname = sprintf('%s_dist.txt',inbase);
[dat] = dlmread(txt_fname);
nSyn = size(dat,1);

tmp_ras=importdata('test_raster.txt');

sTimes = tmp_ras(:,1);
spk_ind=tmp_ras(:,2); 
l_spks=length(sTimes);

idx=zeros(l_spks-1,2);
PSCbase=zeros(l_spks-1,1);

v_EPSP = zeros(60000,l_spks-1);
peak = [];
amp = [];
rise = [];
decay = [];
hfw = [];
% figure(1)
emp_spks=[1 l_spks];
emp_spks2=[];
for k=2:l_spks-1
idx(k,:) = [min(find(t >= sTimes(k)))  max(find(t < sTimes(k+1)))];
% idx(k,2)-idx(k,1);
% figure(1)
% plot(v(idx(k,1):idx(k,2)))
% hold on;
tstep = [0 : idx(k,2)-idx(k,1)-1];
t_EPSP = t(1+tstep);


    idx_EPSP = idx(k,1);
    tmp = v(idx(k,1)+1:idx(k,2));
    [mn,mnI]=min(tmp);
    
    v_EPSP(1+tstep,k-1) = tmp-tmp(1);
%     plot(v_EPSP(:,k-1))
%     hold on;
    peak(end+1,:) = [t_EPSP(mnI)  abs(mn-tmp(1))];
    
    [amp_tmp,rise_tmp,decay_tmp,hfw_tmp]=analyze_EPSC(t_EPSP,tmp); 
    if (decay_tmp~=0)
        amp(end+1)=amp_tmp;
        rise(end+1)=rise_tmp;
        decay(end+1)=decay_tmp;
        hfw(end+1)=hfw_tmp;
    else
        emp_spks=[emp_spks k];
        emp_spks2=[emp_spks2 k];
    end
end

v_EPSP(30000:end,:)=[];

% nSyn = size(v_EPSP,1);
fprintf('Found %d EPSCs\n',length(amp)-length(find(amp==0)));
fprintf('Mean amp\t%.2f\n',mean(nonzeros(amp)*1e3));
fprintf('Mean rise\t%.2f\n',mean(nonzeros(rise)));
fprintf('Mean decay\t%.2f\n',mean(nonzeros(decay)));
fprintf('Mean 1/2 width\t%.2f\n',mean(nonzeros(hfw)));
mean_EPSP=zeros(length(v_EPSP),1);

targ_spks=find(dat(:,2)>=0.4*max(dat(:,2)));

for i=1:length(v_EPSP)
mean_EPSP(i) = mean(v_EPSP(i,targ_spks(1:end-3)));
end

% figure(1)
% l_EPSP=length(v_EPSP);
% t_plot=0:0.025:0.025*(l_EPSP-1);
% for i=1:length(targ_spks)-3
%     if (ismember(i,emp_spks2)==0)
%         if(min(v_EPSP(:,targ_spks(i))*1000)<0)
%         plot(t_plot,v_EPSP(:,targ_spks(i))*1000,'k',t_plot,mean_EPSP*1000,'r');
%         hold on;
%         end
%     end
% end
% % plot(t_plot,mean_EPSP*1000,'r');
% ttl = sprintf('%s:  superimposing all EPSCs',figttl);
% title('superimposed EPSCs');
% xlabel('time (ms)');
% xlim([0 25])
% ylim([-20 1])
% ylabel('EPSC (pA)');
% fname = sprintf('%s_meanEPSCond.fig',inbase);

% figure(2)

distan=zeros(nSyn,1);

% ave_persyn=zeros(nSyn,1);
% spk_indtmp=spk_ind;
% spk_indtmp(emp_spks)=[];
% spks_syn=[spk_indtmp amp'];
% for i=1:length(dat)-3
%     tmp_spks=find(spks_syn(:,1)==i);
%     if(length(spks_syn)>=1)
%     ave_persyn(i)=mean(spks_syn(tmp_spks,2));
%     end
% end
% for i=1:length(dat)
% if ((ave_persyn(i)~=0)&&(dat(i,2)>=0.5*max(dat(:,2))))
% plot(dat(i,2),ave_persyn(i)*1000,'ro')
% hold on;
% end
% end
peak_norm=zeros(length(peak(:,2)),1);
xx=dat(2:end-1,2);

% for i=1:length(peak(:,2))
%     peak_norm(i)=(peak(i,2)-min(peak(:,2)))/(max(peak(:,2))-min(peak(:,2)));
  
 %   xx(i)=(xx(i)-min(dat(2:end-1,2)))/(max(dat(2:end-1,2))-min(dat(2:end-1,2)));
% end



yy=peak_norm(:);
yy_v=peak(:,2);

llx(CEL)=length(xx);
lly(CEL)=length(yy);
xx0(indx:indx+length(xx)-1)=xx;
yy0(indy:indy+length(yy)-1)=yy;
yy_v0(indy:indy+length(yy)-1)=yy_v;
indx=indx+length(xx);
indy=indy+length(xx);
%  plot(xx,yy,'blacko','MarkerFaceColor','black');
% plot(xx,yy,'ro','MarkerFaceColor','red');

% title('Synapse location and EPSC amplitudes');
% xlabel('Traversed distance from soma (microns)');
% ylabel('EPSC amplitude');

cd ..

end
xxx=xx0(1:3000);
yyy=yy0(1:3000);
yyyv=yy_v0(1:3000);
[xxx yyy yyyv]


% figure(3)
% tmp_den=importdata('syn_record.txt');
% syn_ind=tmp_den(3:end-2,1);
% dend_ind=tmp_den(3:end-2,2);
% seg_ind=tmp_den(3:end-2,3);
% uni_dend=unique(dend_ind);
% l_uni=length(uni_dend);
% 
% 
% for i=1:l_uni
%     spec_ind=find(dend_ind(:)==uni_dend(i));
%     spec_syn=syn_ind(spec_ind);   
%     xx_tmp=[];
%     yy_tmp=[];
%     for j=1:length(spec_syn)
%         if(spec_syn(j)<=length(xx))
%         if(xx(spec_syn(j))>=0.4*max(xx))
%          xx_tmp(end+1)=xx(spec_syn(j));
%          yy_tmp(end+1)=yy(spec_syn(j));
%         end
%         end
%     end
%    plot(xx_tmp,yy_tmp,'o-');
%    hold on;
% end
%     


% subplot(1,3,3);
% xbar=[.5:.1:60];
% n_elements=histc(peak(:,2)*1000,xbar);
% npts=max(size(peak));
% c_elements = cumsum(n_elements);
% 
% plot(xbar,c_elements/npts,'o-');

% xlim([0 60]);

% title('Cumulative frequency histograms');
% xlabel('EPSC amplitude (pA)');
% ylabel('cumulative (%)');
% avamp=mean(amp)*1e3;
% tr=mean(rise);
% td=mean(decay);
% avhfw=mean(hfw);
% fprintf('Found %d EPSCs\n',length(amp));
% fprintf('Mean amp\t%.2f\n',mean(amp)*1e3);
% fprintf('Mean rise\t%.2f\n',mean(rise));
% fprintf('Mean decay\t%.2f\n',mean(decay));
% fprintf('Mean 1/2 width\t%.2f\n',mean(hfw));

% figure(2)
% plot(t_plot,mean_EPSP*1000,'r');
% ttl = sprintf('%s:  superimposing all EPSCs',figttl);
% title('superimposed EPSCs');
% xlabel('time (ms)');
% xlim([0 40])
% ylim([-15 1])
% ylabel('EPSC (pA)');
