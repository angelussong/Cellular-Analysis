clear
clc
tmp=importdata('curr_population');
lee=length(tmp);
fput = fopen( 'HETD2_May16IR2e.txt', 'wt' );

for tcount=1:lee
    
T_sim=8000;
trise=tmp(tcount,1);
tdecay=tmp(tcount,2);
gGABA=tmp(tcount,3);
Interval = 10000;
Nspikes = 60;
fint = fopen('main_PFC-ApBas_fig12ipsc.hoc','r');
fout = fopen('main_PFC-ApBas_fig12ipsc_out.hoc','w');
linenum = 0; 
fprintf(fput,'%f\t%f\t%f\t',trise,tdecay,gGABA);
while ~feof(fint)
     tline = fgetl(fint);
     linenum = linenum+1;
     if linenum>=0
        if linenum==188
            fprintf(fout,'   xopen("PFC-V1_AddSynapses_neg.hoc")\n')
        elseif linenum==208
            fprintf(fout,'   endSyn = %d\n',T_sim);
        elseif linenum==213
            fprintf(fout,'   synITweak(nSynapse,%.4f,%.4f,%.7f,"fig12_PFCapic")\n',trise,tdecay,gGABA);       
        else
         fprintf(fout,'%s\n',tline);

        end
     end

end
fclose(fint);
fclose(fout);


fint = fopen('PFC-V1_AddSynapses_negexp.hoc','r');
fout = fopen('PFC-V1_AddSynapses_neg.hoc','w');
linenum = 0; 
while ~feof(fint)
     tline = fgetl(fint);
     linenum = linenum+1;
     if linenum>=0 
        if linenum==22
            fprintf(fout,'INTERVAL = %d\n',Interval);
        elseif linenum==23
            fprintf(fout,'NSPIKES = %d\n',Nspikes);       
        elseif linenum==75
            fprintf(fout,'GABAa_tau1 = %.4f //(ms)\n',trise);
        elseif linenum==76
            fprintf(fout,'GABAa_tau2 = %.4f //(ms),\n',tdecay);       
        elseif linenum==73
            fprintf(fout,'GABAa_g = %.7f // change in conductance,\n',gGABA);
        else
            fprintf(fout,'%s\n',tline);
        end
     end
end
fclose(fint);
fclose(fout);
 


fprintf('Testing parameters ');

fprintf('\n');

syscmd = '/Applications/NEURON-7.5/nrn/x86_64/bin/nrniv -nogui main_PFC-ApBas_fig12ipsc_out.hoc';


system(syscmd);


[avamp,tr,td,avhfw]=read_IPSCsims_mdb(trise,tdecay,gGABA);
fprintf(fput,'%f\t%f\t%f\t%f\n',avamp,tr,td,avhfw);
delete *.Ibin
delete *_dist.txt
end
fclose(fput);

