samePass = 4;
if( samePass == 1)
    ttl_tag = 'SamePass';
    
    WTD1_Apr29IR2a_out = [
        0  0.0365618
        100  0.0868912
        200  0.206315
        300  0.347217
        400  0.485238
        500  0.612573
        ];
    
    WTD1_Apr29IR2a_in = [
        0  0.523068
        100  1.63323
        200  2.1778
        300  2.47355
        400  2.66774
        500  2.8107
        ];
    
    WTD1_Apr29IR2b_out = [
        0  0.0276175
        
        100  0.0607317
        
        200  0.142525
        
        300  0.24363
        
        400  0.346276
        
        500  0.443496
        ];
    
    WTD1_Apr29IR2b_in = [
        0  0.359554
        
        100  1.17633
        
        200  1.68294
        
        300  1.97602
        
        400  2.1736
        
        500  2.32169
        ];
    
    WTD2_Apr12IR1b_out = [
        0  0.159745
        
        100  0.369335
        
        200  0.53757
        
        300  0.693795
        
        400  0.834154
        
        500  0.959204
        ];
    
    WTD2_Apr12IR1b_in = [
        0  0.875692
        
        100  2.04314
        
        200  2.59602
        
        300  2.91341
        
        400  3.13364
        
        500  3.30224
        ];
    
    WTD2_Apr20IR2c_out = [
        0  0.0452989
        
        100  0.12333
        
        200  0.28332
        
        300  0.449644
        
        400  0.600788
        
        500  0.73429
        ];
    
    WTD2_Apr20IR2c_in = [
        0  0.534083
        
        100  1.62711
        
        200  2.13773
        
        300  2.40937
        
        400  2.58656
        
        500  2.71672
        ];
    
    HETD1_Apr13IR3b_out = [
        0  0.0476402
        
        100  0.146563
        
        200  0.276819
        
        300  0.401908
        
        400  0.519214
        
        500  0.627324
        ];
    
    HETD1_Apr13IR3b_in = [
        0  0.898971
        
        100  2.23436
        
        200  2.82006
        
        300  3.15498
        
        400  3.38194
        
        500  3.55106
        ];
    
    HETD1_Apr25IR2a_out = [
        0  0.0265147
        
        100  0.0543122
        
        200  0.126723
        
        300  0.222758
        
        400  0.326293
        
        500  0.428658
        ];
    
    HETD1_Apr25IR2a_in = [
        0  0.480971
        
        100  1.53837
        
        200  2.10544
        
        300  2.4245
        
        400  2.63368
        
        500  2.78475
        ];
    
    HETD1_Apr25IR2c_out = [
        0  0.0314856
        
        100  0.0718063
        
        200  0.169999
        
        300  0.28971
        
        400  0.409887
        
        500  0.522365
        ];
    
    HETD1_Apr25IR2c_in = [
        0  0.501482
        
        100  1.5749
        
        200  2.1147
        
        300  2.40728
        
        400  2.5956
        
        500  2.731
        ];
    
    HETD2_May2IR3e_out = [
        0  0.0321387
        
        100  0.0718848
        
        200  0.170705
        
        300  0.293786
        
        400  0.419301
        
        500  0.538224
        ];
    
    HETD2_May2IR3e_in = [
        0  0.417131
        
        100  1.36613
        
        200  1.91198
        
        300  2.22179
        
        400  2.42765
        
        500  2.5791
        ];
    
    HETD2_May6IR2e_out = [
        0  0.0311499
        
        100  0.0712648
        
        200  0.167036
        
        300  0.282914
        
        400  0.400252
        
        500  0.511745
        ];
    
    HETD2_May6IR2e_in = [
        0  0.50751
        
        100  1.52409
        
        200  2.06486
        
        300  2.36767
        
        400  2.56764
        
        500  2.71372];
end;

if( samePass == 0 )
    CHD_METsubfit;
    ttl_tag = 'CustomPass';
end;
if( samePass == 2 )
    CHD_METsubfit_smth;
    ttl_tag = 'CustomPassSmth';
end;
if( samePass == 3 )
    CHDI_MET_smth_SamePassResults;
    ttl_tag = 'SamePassSmth';
end;
if( samePass == 4 )
    CHDI_MET_smthSamePassDistalRa400;
    ttl_tag = 'SamePassSmthDistalRa400';
end;


% now create graphs
frq = 0:100:500;
subplot(2,2,1);
plot(frq,WTD1_Apr29IR2a_out(:,2),'ko-');
hold on;
plot(frq,WTD1_Apr29IR2b_out(:,2),'ro-');
plot(frq,HETD1_Apr13IR3b_out(:,2),'go--');
plot(frq,HETD1_Apr25IR2a_out(:,2),'co--');
plot(frq,HETD1_Apr25IR2c_out(:,2),'mo--');
plot(frq,WTD2_Apr12IR1b_out(:,2),'ks-');
plot(frq,WTD2_Apr20IR2c_out(:,2),'rs-');
plot(frq,HETD2_May2IR3e_out(:,2),'cs--');
plot(frq,HETD2_May6IR2e_out(:,2),'ms--');

leg={'WTD1 Apr29IR2a','WTD1 Apr29IR2b','HETD1 Apr13IR3b','HETD1 Apr25IR2a','HETD1 Apr25IR2c',...
    'WTD2 Apr12IR1b','WTD2 Apr20IR2c','HETD2 May2IR3e','HETD2 May6IR2e'};
legend(leg);
ttl = sprintf('Lout %s',ttl_tag);
title(ttl);

subplot(2,2,2);
plot(frq,WTD1_Apr29IR2a_in(:,2),'ko-');
hold on;
plot(frq,WTD1_Apr29IR2b_in(:,2),'ro-');
plot(frq,HETD1_Apr13IR3b_in(:,2),'go--');
plot(frq,HETD1_Apr25IR2a_in(:,2),'co--');
plot(frq,HETD1_Apr25IR2c_in(:,2),'mo--');
plot(frq,WTD2_Apr12IR1b_in(:,2),'ks-');
plot(frq,WTD2_Apr20IR2c_in(:,2),'rs-');
plot(frq,HETD2_May2IR3e_in(:,2),'cs--');
plot(frq,HETD2_May6IR2e_in(:,2),'ms--');

leg={'WTD1 Apr29IR2a','WTD1 Apr29IR2b','HETD1 Apr13IR3b','HETD1 Apr25IR2a','HETD1 Apr25IR2c',...
    'WTD2 Apr12IR1b','WTD2 Apr20IR2c','HETD2 May2IR3e','HETD2 May6IR2e'};
legend(leg);
ttl = sprintf('Lin %s',ttl_tag);
title(ttl);
figname = sprintf('CHDI_prelim_LoutLin_%sParams.fig',ttl_tag);
% saveas(gcf,figname);

%
% create average of each group.


    WTD1_mean(:,1) = mean([WTD1_Apr29IR2a_out(:,2) WTD1_Apr29IR2b_out(:,2)],2);
    WTD1_mean(:,2) = mean([WTD1_Apr29IR2a_in(:,2) WTD1_Apr29IR2b_in(:,2)],2);

    HETD1_mean(:,1) = mean([HETD1_Apr13IR3b_out(:,2) HETD1_Apr25IR2a_out(:,2) HETD1_Apr25IR2c_out(:,2)],2);
    HETD1_mean(:,2) = mean([HETD1_Apr13IR3b_in(:,2) HETD1_Apr25IR2a_in(:,2) HETD1_Apr25IR2c_in(:,2)],2);
    
    WTD2_mean(:,1) = mean([WTD2_Apr12IR1b_out(:,2) WTD2_Apr20IR2c_out(:,2)],2);
    WTD2_mean(:,2) = mean([WTD2_Apr12IR1b_in(:,2) WTD2_Apr20IR2c_in(:,2)],2);

    HETD2_mean(:,1) = mean([HETD2_May2IR3e_out(:,2) HETD2_May6IR2e_out(:,2)],2);
    HETD2_mean(:,2) = mean([HETD2_May2IR3e_in(:,2) HETD2_May6IR2e_in(:,2)],2);
    
%     figure;
    subplot(2,2,3);
    p=plot(frq,WTD1_mean(:,1),'ko-',frq,HETD1_mean(:,1),'go--',frq,WTD2_mean(:,1),'ks-',frq,HETD2_mean(:,1),'cs--');
    for i=1:4 set(p(i),'MarkerSize',10); set(p(i),'LineWidth',1); end;
    leg={'WTD1','HETD1','WTD2','HETD2'};
    legend(leg);
    ttl = sprintf('means:  Lout %s',ttl_tag);
    title(ttl);

    subplot(2,2,4);
    p=plot(frq,WTD1_mean(:,2),'ko-',frq,HETD1_mean(:,2),'go--',frq,WTD2_mean(:,2),'ks-',frq,HETD2_mean(:,2),'cs--');
    for i=1:4 set(p(i),'MarkerSize',10); set(p(i),'LineWidth',1); end;
    leg={'WTD1','HETD1','WTD2','HETD2'};
    legend(leg);
    ttl = sprintf('means:  Lin %s',ttl_tag);
    title(ttl);

figname = sprintf('CHDI_prelim_LoutLinPlusMeans_%sParams.fig',ttl_tag);
saveas(gcf,figname);




