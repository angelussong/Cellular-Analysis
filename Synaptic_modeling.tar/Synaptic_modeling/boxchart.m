clear
clc

tmp1=importdata('boxchartIPSC.txt');
neuron_alias=tmp1(1,:);
riset=tmp1(2,:);
decayt=tmp1(3,:);
ggaba=tmp1(4,:);
interv=1./tmp1(5,:);


subplot(2,2,1);
boxplot(riset,neuron_alias)
title('Tau rise');
xlabel('Neuron type');
ylabel('Rise time constant (ms)');
neuronnames={'WT D1'; 'Q175 D1'; 'WT D2'; 'Q175 D2' };
set(gca,'xticklabel',neuronnames)


subplot(2,2,2);
boxplot(decayt,neuron_alias)
title('Tau decay');
xlabel('Neuron type');
ylabel('Decay time constant (ms)');
neuronnames={'WT D1'; 'Q175 D1'; 'WT D2'; 'Q175 D2' };
set(gca,'xticklabel',neuronnames)


subplot(2,2,3);
boxplot(ggaba,neuron_alias)
title('Max GABAR conductance');
xlabel('Neuron type');
ylabel('Max GABAR conductance (nS)');
neuronnames={'WT D1'; 'Q175 D1'; 'WT D2'; 'Q175 D2' };
set(gca,'xticklabel',neuronnames)

subplot(2,2,4);
boxplot(interv,neuron_alias)
title('Synapse activation frequency');
xlabel('Neuron type');
ylabel('Synapse activation frequency (Hz)');
neuronnames={'WT D1'; 'Q175 D1'; 'WT D2'; 'Q175 D2' };
set(gca,'xticklabel',neuronnames)